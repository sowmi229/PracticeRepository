import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Source {

	public static void main(String[] args) {
List<Integer> numbers=Arrays.asList(4,5,6,7,8,9);
numbers.stream()
.forEach(System.out::println);

//List<Department> dept=new ArrayList<Department>();
//dept.add(new Department(101,"Testing",6,"chennai",new Date(2019,11,15),41000));
//dept.add(new Department(103,"Payroll",8,"mumbai",new Date(2019,10,15),36000));
//dept.add(new Department(102,"Production",6,"mumbai",new Date(2020,11,15),33000));
//dept.add(new Department(104,"Developement",10,"chennai",new Date(2020,11,15),55000));


Set<Department> tsdept=new TreeSet<Department>();
tsdept.add(new Department(101,"Testing",6,"chennai",new Date(2019,11,15),41000));
tsdept.add(new Department(103,"Payroll",8,"mumbai",new Date(2019,10,15),36000));
tsdept.add(new Department(102,"Production",6,"mumbai",new Date(2020,11,15),33000));
tsdept.add(new Department(104,"Developement",10,"chennai",new Date(2020,11,15),55000));

System.out.println("Total Salary by Department Name");

Map<String,Integer> deptsum=tsdept.stream()
.collect(Collectors.groupingBy(t -> t.getDepartmentName()
		,Collectors.summingInt(value ->value.getSalary())));
System.out.println(deptsum);


Map<String, Integer> summ = tsdept.stream()
.collect(Collectors.groupingBy(Department::getDepartmentName,
		Collectors.summingInt(Department::getSalary)));



for(Map.Entry<String, Integer> m: deptsum.entrySet()) {
	System.out.println(m.getKey() + " : "+ m.getValue());
}

//maxby returns maximum element wrapped in an optional object based on the supplied comparator
System.out.println("=========== Maximum Salary by Location========");

Map<Object, Optional<Department>> maxloc=tsdept.stream()
.collect(Collectors.groupingBy(t -> t.getLocation(),
		Collectors.maxBy(Comparator.comparingDouble(value ->value.getSalary() ))
		));


for(Entry<Object, Optional<Department>> map: maxloc.entrySet()) {
	Department sal=map.getValue().get();
	System.out.println("Location "+ map.getKey() + " "+ " maximum salary "+ sal.getSalary());
}

tsdept.stream()
.map(Department::getDepartmentName)
.distinct()
.forEach(System.out::println);

tsdept.stream()
.collect(Collectors.groupingBy(Department::getDepartmentName
		,Collectors.counting()));

	}
}
