import java.util.*;

public class MethodReferenceDemo {

	public static void main(String[] args) {
		List<String> names= Arrays.asList("Saurabh","Pooja","Chetana","Jensi","Chandrika","Chandrakirani");
		List<Integer> numbers=Arrays.asList(3,4,5,6,7);
		
		numbers.stream()
		.map(t->t*t)
		.forEach(System.out::println);
		
		
		
		
	}

}
