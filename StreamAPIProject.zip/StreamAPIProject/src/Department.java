import java.util.Date;

public class Department implements Comparable<Department> {
private int departmentId;
private String departmentName;
private int noofEmployees;
private String location;
private Date doj;
private int salary;	
@Override
public int compareTo(Department o) {
	return this.departmentId-o.departmentId;
}
public Department() {
	super();
	// TODO Auto-generated constructor stub
}
public Department(int departmentId, String departmentName, int noofEmployees, String location, Date doj, int salary) {
	super();
	this.departmentId = departmentId;
	this.departmentName = departmentName;
	this.noofEmployees = noofEmployees;
	this.location = location;
	this.doj = doj;
	this.salary=salary;
}
public int getDepartmentId() {
	return departmentId;
}
public void setDepartmentId(int departmentId) {
	this.departmentId = departmentId;
}
public String getDepartmentName() {
	return departmentName;
}
public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
}
public int getNoofEmployees() {
	return noofEmployees;
}
public void setNoofEmployees(int noofEmployees) {
	this.noofEmployees = noofEmployees;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}

public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + ", noofEmployees="
			+ noofEmployees + ", location=" + location + ", doj=" + doj + ", salary=" + salary + "]";
}

}


	